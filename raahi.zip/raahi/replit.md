# Overview

This is a comprehensive Pomodoro Focus Mode feature built with React, TypeScript, and modern web technologies. The application provides a complete productivity timer system with focus sessions, break management, statistics tracking, and premium glassmorphic UI components. It includes an analog clock, digital time display, mini calendar, music player, progress ring timer, and detailed analytics with export capabilities.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

**Framework**: React with TypeScript using Vite as the build tool
- **Component Structure**: Modular component design with dedicated focus mode components under `/client/src/components/focus/`
- **State Management**: Custom React hooks for Pomodoro timer logic with localStorage persistence via `usePomodoro.ts`
- **Routing**: Wouter for lightweight client-side routing
- **UI Framework**: Radix UI components with shadcn/ui design system and custom Tailwind styling
- **Data Fetching**: TanStack Query for server state management and caching

**Key Components**:
- `ProgressRing`: Animated circular timer with SVG-based visual progress indicator
- `Controls`: Timer controls with keyboard shortcuts (spacebar, 'r', 's') and session type switching
- `StatsPanel`: Real-time statistics display for daily focus metrics
- `AnalogClock` & `DigitalTimeGreeting`: Premium time display with glassmorphic styling and smooth animations
- `MiniCalendar`: Apple-style glassmorphic calendar with today highlighting
- `MusicPlayer`: Relaxation music player with mock track support
- `GraphCard`: SVG-based weekly focus visualization with peak hour highlighting
- `ReportsCard`: Data export functionality (CSV/PDF) and email settings
- `SettingsModal`: Comprehensive settings for timer durations, notifications, and preferences

**State Management Pattern**: 
- Custom `usePomodoro` hook implements complete timer state machine with three session types
- localStorage persistence for session continuity and settings across browser restarts
- Settings management with real-time updates and event-driven architecture
- Session types: focus (25min), short break (5min), long break (15min) with configurable durations

**Styling Architecture**:
- Custom CSS variables for Capella Pro brand colors (light teal buttons, dark teal accents)
- Glassmorphic effects using backdrop-blur and semi-transparent backgrounds
- Responsive grid layouts with mobile-first approach
- Premium visual effects including smooth animations and shadows

## Backend Architecture

**Server Framework**: Express.js with TypeScript
- **API Design**: RESTful endpoints for focus session lifecycle management
- **Session Tracking**: Complete CRUD operations for focus session data
- **Statistics Generation**: Real-time aggregation of user productivity metrics
- **Export Services**: PDF and CSV generation for analytics reports

**API Endpoints**:
- `POST /api/focus/start` - Initialize new focus session with validation
- `POST /api/focus/end` - Complete focus session with actual duration tracking
- `GET /api/focus/stats` - Retrieve user statistics (daily/weekly/monthly aggregations)
- `POST /api/focus/export` - Generate and download reports in multiple formats

**Architecture Decision**: Modular storage interface (`IStorage`) allows seamless switching between in-memory storage (development) and Firebase/PostgreSQL (production) without changing business logic. Storage abstraction supports multiple database backends.

## Data Storage Solutions

**Database Schema** (Drizzle ORM with PostgreSQL):
- **Users Table**: Basic user authentication and profile data
- **Focus Sessions Table**: Complete session tracking with start/end times, duration metrics, session types, and completion status
- **Schema Design**: Optimized for analytics queries with proper indexing on user_id and date fields

**Data Models**:
- Session types: 'focus', 'short_break', 'long_break' with configurable durations
- Tracking both requested duration and actual completion time for analytics
- Boolean completion flags for accurate statistics calculation

**Storage Interface**: Abstract storage layer with implementations for:
- In-memory storage for development and testing
- Firebase Firestore integration (configured via environment variables)
- PostgreSQL support via Drizzle ORM for production deployment

## External Dependencies

**Core Frontend Libraries**:
- **React 18** with TypeScript for component architecture
- **Vite** for fast development and optimized builds
- **TanStack Query** for server state management and caching
- **Wouter** for lightweight client-side routing
- **Radix UI** for accessible component primitives
- **Tailwind CSS** with custom Capella Pro design tokens

**UI and Styling**:
- **shadcn/ui** component library for consistent design system
- **Lucide React** for premium icon set
- **class-variance-authority** for component variant management
- **clsx** and **tailwind-merge** for conditional styling

**Backend Dependencies**:
- **Express.js** for server framework
- **Drizzle ORM** for type-safe database operations
- **Zod** for request/response validation
- **@neondatabase/serverless** for PostgreSQL connectivity

**Development Tools**:
- **TypeScript** for type safety across frontend and backend
- **ESBuild** for fast server-side bundling
- **PostCSS** and **Autoprefixer** for CSS processing

**Optional Integrations**:
- **Firebase** (configurable via `USE_FIREBASE` environment variable)
- **Firebase Admin SDK** for server-side operations
- **PDF generation libraries** for report exports
- **Email services** for weekly summary delivery

**Configuration Requirements**:
- `DATABASE_URL` for PostgreSQL connection
- `USE_FIREBASE` boolean flag for storage backend selection
- Firebase configuration variables (when using Firebase backend)
- SMTP settings for email notifications (optional)

The application is designed for easy deployment on Replit with all dependencies properly configured and environment variable support for different deployment scenarios.