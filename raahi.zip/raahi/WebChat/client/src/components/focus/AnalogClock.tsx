import { useState, useEffect } from "react";

export default function AnalogClock() {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 100); // Update every 100ms for smooth second hand
    return () => clearInterval(timer);
  }, []);

  const hours = time.getHours() % 12;
  const minutes = time.getMinutes();
  const seconds = time.getSeconds();
  const milliseconds = time.getMilliseconds();

  // Calculate angles with smooth movement
  const hourAngle = (hours * 30) + (minutes * 0.5) + (seconds * 0.00833); // Smooth hour hand
  const minuteAngle = (minutes * 6) + (seconds * 0.1); // Smooth minute hand
  const secondAngle = (seconds * 6) + (milliseconds * 0.006); // Smooth second hand

  // Generate hour markers - all uniform size
  const hourMarkers = [];
  for (let i = 0; i < 12; i++) {
    const angle = i * 30;
    const x1 = 100 + Math.cos((angle - 90) * Math.PI / 180) * 85;
    const y1 = 100 + Math.sin((angle - 90) * Math.PI / 180) * 85;
    const x2 = 100 + Math.cos((angle - 90) * Math.PI / 180) * 75;
    const y2 = 100 + Math.sin((angle - 90) * Math.PI / 180) * 75;
    
    hourMarkers.push(
      <line 
        key={`hour-${i}`}
        x1={x1} 
        y1={y1} 
        x2={x2} 
        y2={y2} 
      />
    );
  }

  // Generate minute markers (skip hour positions)
  const minuteMarkers = [];
  for (let i = 0; i < 60; i++) {
    if (i % 5 !== 0) { // Skip hour markers
      const angle = i * 6;
      const x1 = 100 + Math.cos((angle - 90) * Math.PI / 180) * 90;
      const y1 = 100 + Math.sin((angle - 90) * Math.PI / 180) * 90;
      const x2 = 100 + Math.cos((angle - 90) * Math.PI / 180) * 85;
      const y2 = 100 + Math.sin((angle - 90) * Math.PI / 180) * 85;
      
      minuteMarkers.push(
        <line 
          key={`minute-${i}`}
          x1={x1} 
          y1={y1} 
          x2={x2} 
          y2={y2} 
        />
      );
    }
  }

  return (
    <div className="flex justify-center">
      <div className="relative w-64 h-64">
        <div className="rounded-full w-full h-full">
          <svg viewBox="0 0 200 200" className="w-full h-full">
            {/* Clean clock face - no borders */}
            <circle 
              cx="100" 
              cy="100" 
              r="95" 
              fill="rgba(255, 255, 255, 0.05)" 
              stroke="none"
            />
            
            {/* Hour markers only - clean minimal design */}
            <g stroke="rgba(100, 100, 100, 0.6)" strokeWidth="2" strokeLinecap="round">
              {hourMarkers}
            </g>
            
            {/* Clock hands with smooth movement */}
            {/* Hour hand */}
            <line 
              x1="100" 
              y1="100" 
              x2="100" 
              y2="55" 
              stroke="rgba(60, 60, 60, 0.9)" 
              strokeWidth="4" 
              strokeLinecap="round" 
              className="clock-smooth" 
              style={{ transform: `rotate(${hourAngle}deg)` }}
            />
            
            {/* Minute hand */}
            <line 
              x1="100" 
              y1="100" 
              x2="100" 
              y2="35" 
              stroke="rgba(60, 60, 60, 0.8)" 
              strokeWidth="2" 
              strokeLinecap="round" 
              className="clock-smooth" 
              style={{ transform: `rotate(${minuteAngle}deg)` }}
            />
            
            {/* Second hand */}
            <line 
              x1="100" 
              y1="100" 
              x2="100" 
              y2="25" 
              stroke="#ef4444" 
              strokeWidth="2" 
              strokeLinecap="round" 
              className="clock-smooth" 
              style={{ transform: `rotate(${secondAngle}deg)` }}
            />
            
            {/* Center dot */}
            <circle cx="100" cy="100" r="5" fill="rgba(0, 139, 139, 0.9)" />
            <circle cx="100" cy="100" r="2" fill="#ef4444" />
          </svg>
        </div>
      </div>
    </div>
  );
}